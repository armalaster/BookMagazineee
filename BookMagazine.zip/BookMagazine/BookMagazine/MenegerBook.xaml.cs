﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BookMagazine.DB;

namespace BookMagazine
{
    /// <summary>
    /// Логика взаимодействия для MenegerBook.xaml
    /// </summary>
    public partial class MenegerBook : Page
    {
        public MagazinBookEntities Connect = new MagazinBookEntities();
        public ObservableCollection<Book> Books { get; set; }
        public Book AddBook { get; set; }
        public MenegerBook()
        {
            InitializeComponent();
            
            AddBook = new Book(); //добавление
            BookList.IsEnabled = true; //удаление
            Books = new ObservableCollection<Book>(Connect.Books.ToList());
            DataContext = this;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Connect.Books.Add(AddBook);
            int result = Connect.SaveChanges();
            if (result != 0)
            {
                Connect.Books.Add(AddBook);
                AddBook = new Book();
                MessageBox.Show("Книга добавлена.");
            }
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Хотите удалить?","Удаление",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Connect.Books.Remove(Books[BookList.SelectedIndex]);
                Connect.SaveChanges();

                Books = new ObservableCollection<Book>(Connect.Books.ToList());
                BookList.ItemsSource = Books;
            }
        }

        //Поиск
        public void Search(string substring)
        {
            ICollectionView nb = CollectionViewSource.GetDefaultView(BookList.ItemsSource);
            if (nb == null) return;
            int nbcounter = 0;
            nb.Filter = new System.Predicate<object>(obj =>
            {
                bool isnb = ((Book)obj).NameBook.ToLower().Contains(substring.ToLower());
                if (isnb) nbcounter++;
                return isnb;
            });

        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Search(TextBox.Text);
        }

        //Поиск
    }
}
